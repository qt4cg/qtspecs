This zipfile contains the XML source for the XPath/XQuery family 
of grammars, the jj and jjt source for 
for JavaCC/JJTree (https://javacc.dev.java.net/) parser generation, 
the generated java source, and the generated xpath.jar.

xpath-grammar.xml is the source for the grammar.  It is used to generate both the EBNF in the 
language documents, as well as the JavaCC test parsers.  This is mainly for your
general information.  (The transformations files etc. are not included in this 
particular package).

The parser directory contains xpath.jar.

The parser/xpath-src directory contains the jj jjt and java files.

You can run the Jars on the command line via:

java -jar xquery.jar

Which will prompt for an expression.

Running:
java -jar xquery.jar -file [filename]

Will parse a file, and report errors, but will not dump any other diagnostics.

java -jar xquery.jar -dumptree -file [filename]

will cause a diagnostic syntax tree to be dumped.

Calling the API:

I don't have good JavaDocs right now for calling the API.  Here's an illustrative sample:

import java.io.StringReader;

public class APITest1 {

    public static void main(String[] args) throws ParseException {
        // There's also API's for a InputStream, but you're better off
        // using a reader, since the reader should deliver properly
        // decoded characters.
        StringReader sr = new StringReader("foo/baz[3]");
        XPath parser = new XPath(sr);
        SimpleNode root = parser.XPath2();

        recursiveProcessingIllustration(root);
        System.out.println();
        System.out.println("=========");

        // Diagnostics dump.
        root.dump("->  ");
    }

    /**
     * Generally show how to process the tree.
     * @param node
     */
    static void recursiveProcessingIllustration(SimpleNode node) {
        switch (node.id) {
        case XPathTreeConstants.JJTQNAME:
            System.out.print("qname: ");
            System.out.print(node.getValue());
            break;

        case XPathTreeConstants.JJTABBREVFORWARDSTEP:
            System.out.print("child::");
            break;

        // etc.

        default:
            System.out.print(XPathTreeConstants.jjtNodeName[node.id]);
        }

        for (int i = 0; i < node.jjtGetNumChildren(); i++) {
            SimpleNode child = (SimpleNode) node.jjtGetChild(i);
            System.out.print(", ");
            recursiveProcessingIllustration(child);
        }
    }
}


